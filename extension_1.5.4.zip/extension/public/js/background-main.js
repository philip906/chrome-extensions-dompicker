require.config({
    baseUrl: 'public/js',
});

require(['lib/underscore', 'utilities/util'], function(_, Util) { 
    /**
     * Listen for message from content script wrapper
     * message format for saveValues:
     *      message: {
     *          'method': 'methodName',
     *          'toolName': 'toolName',
     *          'value': 'value'
     *      }
     */
    chrome.runtime.onMessage.addListener(function(message){
        console.log('recieveing message from CS');
        switch(message.method) {
            case 'saveValue':
                BackgroundApi.saveValue(message.toolName, message.value);
                break;
            default:
                console.log('[DEBUG] did not find a method in the message...');
                break;
        }
    });
    chrome.webNavigation.onDOMContentLoaded.addListener(_restoreState);

    function _restoreState() {
        var slToolCookie = Util.getCookie('sl-tool');
        if (slToolCookie) {
            slToolValues = slToolCookie.split('|');
            for (var i = 0; i < slToolValues.length; i++) {
                var slToolValueParts = slToolValues[i].split('=');
                window.BackgroundApi.notifyCS(slToolValueParts[0], slToolValueParts[1]);
            }
        }
    }


    function _sendMessageToCS(message) {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, message, function(response) {
                if (response) {
                    console.log('[INFO] message sent successfully to CS', response);
                    window.BackgroundApi.csCookies = response.csCookies;
                } else {
                    console.log('[DEBUG] something happened to the message...');
                }
            });
        });
    }

    window.BackgroundApi = {
        util: Util,
        /**
         * Called from the popup this will save a value of a tool
         * @param toolName {string} - the name of the tool (i.e. 'ag')
         * @param value {string} - the value of the tool (i.e. 'on')
         * @param shouldNotifyCS {boolean} - whether we should notify the Content Script Wrapper of the change
         */
        saveValue: function(toolName, value, shouldNotifyCS) {
            var newSLToolValue = '';
            var isNewValue = true;
            var slToolCookie = this.util.getCookie('sl-tool');
            if (slToolCookie)  {
                slToolValues = slToolCookie.split('|');
                for (var i = 0; i < slToolValues.length; i++) {
                    var slToolValueParts = slToolValues[i].split('=');
                    if (slToolValueParts[0] === toolName) {
                        newSLToolValue += slToolValueParts[0] + '=' + value + '|';
                        isNewValue = false;
                    } else {
                        newSLToolValue += slToolValueParts[0] + '=' + slToolValueParts[1] + '|';
                    }
                }
                newSLToolValue = this.util.removeLastCharacters(newSLToolValue, 1);
            } else {
                newSLToolValue =  toolName + '=' + value;
            } 

            if (isNewValue) {
                newSLToolValue += '|' + toolName + '=' + value;
            }

            this.util.setCookie('sl-tool', newSLToolValue);
            if (shouldNotifyCS) {
                this.notifyCS(toolName, value);
            }
        },

        getValue: function(toolName, toolType) {
            /* if this is a cookie tool then we want to pass the csCookies to the getCookie 
                and find if there is a value */
            if (toolType === 'cookie') {
                return this.util.getCookie(toolName, this.csCookies);
            } else if (toolType === 'tool') {
                var slToolCookie = this.util.getCookie('sl-tool');
                if (slToolCookie) {
                    slToolValues = slToolCookie.split('|');
                    for (var i = 0; i < slToolValues.length; i++) {
                        var slToolValueParts = slToolValues[i].split('=');
                        if (slToolValueParts[0] === toolName) {
                            return slToolValueParts[1];
                        } 
                    }
                }    
            } else {
                console.log('[DEBUG] ' + toolType + ' is not an accepted too type...');
            }
        },

        notifyCS: function(toolName, value) {
            _sendMessageToCS({
                    'method': 'notifyCS',
                    'toolName': toolName,
                    'value': value
                }
            )
        },
        /* populated when content scripts are called */
        csCookies: ''
    };

});