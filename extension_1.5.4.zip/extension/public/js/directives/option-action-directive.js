app.directive('slOptionAction', function() {
    return {
        restrict: 'A',
        template:
            '<span ' + 
                'class="option-action button" ' +
                'ng-click="optionActionClick()">' +
                '{{slTitle}}' +
            '</span>',
        replace: true,
        scope: {
            slToolName: "@",
            slToolType: "@",
            slValue: "@",
            slIsDefault: "@",
            slTitle: "@"
        },
        link: function(scope, $element, attrs) {
            updateVisibleActions(scope.$parent.getValue(scope.slToolName, scope.slToolType));

            scope.optionActionClick = function() {
                scope.$parent.optionActionClick(scope.slToolName, scope.slValue);
                updateVisibleActions(scope.slValue);
            };

            function updateVisibleActions(currentValue) {
                scope.currentValue = currentValue;
                if (scope.currentValue === scope.slValue) {
                    $element.parent().children().removeClass('ng-hide');
                    $element.addClass('ng-hide');
                } else if (!scope.currentValue && scope.slIsDefault) {
                    $element.parent().children().addClass('ng-hide');
                    $element.removeClass('ng-hide');
                }    
            }

        }
    }
});