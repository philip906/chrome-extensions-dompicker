require.config ({
    baseUrl: chrome.extension.getURL("/public/js"),
    paths: {
        'jquery': 'lib/jquery/jquery',
        'jquery-ui': 'lib/jquery/jquery-ui',
        'ag': 'cs/modules/ag/ag',
        'cookies': 'cs/modules/cookies'
    },
    shim: {
        'jquery-ui': ['jquery']
    }
});

require(['ag', 'jquery', 'cookies'], function(AG, r$, Cookies){

    /**
     * Listen for message from background
     * message format for changeStatus:
     *      message: {
     *          'method': 'methodName',
     *          'toolName': 'toolName',
     *          'value': 'value',
     *      }
     */
    chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
        var response = {
            'message': 'CS recieved message',
            'csCookies': document.cookie
        }
        sendResponse(response);
        window.ContentScriptApi[message.method](message.toolName, message.value);
    });

    window.ContentScriptApi = {
        /**
         * Sends value to background page to be saved and stored as cookie
         * @param toolName - the name of the tool (i.e. 'ag')
         * @param value - the value of the tool (i.e. 'off')
         */
        saveValue: function(toolName, value) {
            chrome.runtime.sendMessage({
                "method": "saveValue",
                "toolName": toolName,
                "value": value
            });
        },
        /**
         * Sends notification to the content script letting it know of a value change
         * @param toolName - the name of the tool (i.e. 'ag')
         * @param value - the value of the tool (i.e. 'off')
         */
        notifyCS: function(toolName, value) {
            switch(toolName) {
                case 'ag':
                    AG.notifyTool(value);
                    break;
                case 'rondavu_debug':
                case 'rondavu_qa':
                case 'rdv_test_group':
                    Cookies.notifyTool(toolName, value);
                    break;
            }
        }
    };



});