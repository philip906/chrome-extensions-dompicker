define([], function() {

    var Cookies = {
        notifyTool: function(toolName, value) {
            document.cookie = toolName + '=' + value + "; path=/";
            console.log('[INFO] ' + toolName + ' cookie executed with value ' + value);
        }
    };

    return Cookies;

});