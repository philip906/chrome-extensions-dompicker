app.controller('PopupController', function($scope) {

    function _saveValue(toolName, value) {
        this.chrome.extension.getBackgroundPage().BackgroundApi.saveValue(toolName, value, true);
    }

    function _notifyCS(toolName, value) {
        this.chrome.extension.getBackgroundPage().BackgroundApi.notifyCS(toolName, value);
    }

    /*
    * returns the value currently stored in a background cookie for a tool
    * @param toolName {string} - the name of the tool to get the value of
    * @param toolType {string} - the type of tool we are getting value for (i.e. 'tool' or 'cookie')
    */
    $scope.getValue = function(toolName, toolType) {
        return chrome.extension.getBackgroundPage().BackgroundApi.getValue(toolName, toolType);
    }

    /*
    * When action is clicked we notify the content scripts of the changes, we then see if
        we need to keep the data or not and if so save it
    * @param keepData {boolean} - if we should keep the data
    * @param toolName {string} - the short name of the tool (i.e. 'ag')
        -use null if no value
    * @param value {string} - the value to associate with the tool
    */
    $scope.optionActionClick = function(keepData, toolName, value) {
        _notifyCS(toolName, value);
        if (keepData) {
            _saveValue(toolName, value);   
        } 
    }
});

