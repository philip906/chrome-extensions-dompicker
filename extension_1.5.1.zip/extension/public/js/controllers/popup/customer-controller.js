app.controller("CustomerController", function($scope, $http) {
    $http.get('http://qa.rondavu.com.s3.amazonaws.com/tools/plugins/sl-tool/data/customers-data.json').success(function(response) {
        $scope.customers = response.customers;
    });
});
